Aktuální adresářová struktura:

Text_prace
- Adresář obsahuje zdrojový text této práce napsaný v Microsoft Word.
- Dále obsahuje obrázky využité v práci.

Aplikace_a_knihovny
- Adresář obsahuje projekt vyvíjeného nástroje.
- Adresář také obsahuje Readme.txt, který popisuje jak nástroj sestavit a spustit.
- Dále je zde obsažen soubor agent.jar (již sestavený nástroj)
- Adresář javadoc obsahuje exportovanou Java dokumentaci v HTML formátu


Vysledky
- Adresář obsahuje výsledky testů popsaných v kapitole 7.10.
- Každý soubor je pojmenován podle testu, ze kterého byl vytvořen.

Readme.txt
- Soubor s detailním popisem aktuální adresářové struktury.

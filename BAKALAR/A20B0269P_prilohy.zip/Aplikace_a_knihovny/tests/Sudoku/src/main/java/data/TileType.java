package data;

public enum TileType {
	NORMAL, CORNER
}

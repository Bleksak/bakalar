package data;

public enum SudokuMode {
	CREATE,
	PLAY,
    PLAY_CORNER
}

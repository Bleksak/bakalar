package inject;

public interface IDuplicateEquals {
    boolean eq(Object a, Object b);
}
